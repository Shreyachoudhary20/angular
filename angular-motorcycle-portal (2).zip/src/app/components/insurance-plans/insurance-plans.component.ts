import { Component } from '@angular/core';

@Component({
  selector: 'app-insurance-plans',
  templateUrl: './insurance-plans.component.html',
  styleUrls: ['./insurance-plans.component.css']
})
export class InsurancePlansComponent {}
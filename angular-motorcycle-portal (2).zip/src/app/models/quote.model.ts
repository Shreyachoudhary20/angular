export interface Quote {
  id: string;
  customerName: string;
  address: string;
  contact: string;
  vehicleMake: string;
  vehicleModel: string;
  vehicleYear: number;
  idv: number;
  optionalCoverage: string[];
  premium: number;
  status: 'SUBMITTED' | 'APPROVED' | 'PENDING';
  createdDate: string;
}
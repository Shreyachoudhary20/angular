import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { QuoteService } from '../../services/quote.service';
import { Quote } from '../../models/quote.model';

@Component({
  selector: 'app-quote-form',
  templateUrl: './quote-form.component.html',
  styleUrls: ['./quote-form.component.css']
})
export class QuoteFormComponent {
  quoteForm: FormGroup;
  premium: number = 0;

  constructor(private fb: FormBuilder, private quoteService: QuoteService) {
    this.quoteForm = this.fb.group({
      customerName: [''],
      address: [''],
      contact: [''],
      vehicleMake: [''],
      vehicleModel: [''],
      vehicleYear: [''],
      idv: [0],
      optionalCoverage: [[]]
    });
  }

  calculatePremium() {
    const idv = this.quoteForm.value.idv;
    const coverages = this.quoteForm.value.optionalCoverage.length;
    this.premium = idv * 0.05 + coverages * 50;
  }

  submit() {
    const formValue = this.quoteForm.value;
    const newQuote: Quote = {
      id: 'MQ-' + Date.now(),
      premium: this.premium,
      status: 'PENDING',
      createdDate: new Date().toISOString().split('T')[0],
      ...formValue
    };
    this.quoteService.addQuote(newQuote);
  }
}
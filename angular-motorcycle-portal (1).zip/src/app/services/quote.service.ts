import { Injectable } from '@angular/core';
import { Quote } from '../models/quote.model';
import { Observable, of } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class QuoteService {
  private quotes: Quote[] = [];

  getQuotes(): Observable<Quote[]> {
    return of(this.quotes);
  }

  getQuoteById(id: string): Quote | undefined {
    return this.quotes.find(q => q.id === id);
  }

  addQuote(quote: Quote): void {
    this.quotes.push(quote);
  }

  updateQuote(quote: Quote): void {
    const index = this.quotes.findIndex(q => q.id === quote.id);
    if (index !== -1) this.quotes[index] = quote;
  }

  deleteQuote(id: string): void {
    this.quotes = this.quotes.filter(q => q.id !== id);
  }
}